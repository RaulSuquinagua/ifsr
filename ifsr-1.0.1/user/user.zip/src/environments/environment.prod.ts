export const environment = {
  production: true,
  currency: '$',
  firebase: {
    apiKey: "AIzaSyBEf4CY1Qf5AV546v9lQpvhYn4evV-ek7I",
    authDomain: "codeziporg.firebaseapp.com",
    databaseURL: "https://codeziporg.firebaseio.com",
    projectId: "codeziporg",
    storageBucket: "codeziporg.appspot.com",
    messagingSenderId: "305439070990",
    appId: "1:305439070990:web:08225700f092aaec6d155f"
  }
};